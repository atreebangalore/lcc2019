## highlight.js

highlight.js is a jQuery plugin, Highlight Keywords on Page


## Demo and Documentation

[GitHub Pages](http://yjseo29.github.io/highlight.js).

## Authors

[yjseo29](https://github.com/yjseo29).

## Copyright and license

Copyright (C) 2016 [yjteam](http://yjteam.co.kr)

Licensed under [the MIT license](LICENSE).